set -euo pipefail
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd $SCRIPT_DIR/..
find . -type f -name "*.post.sol" -delete
scripts/install_deps.sh
scripts/pre_forge.sh clean
forge soldeer push --dry-run sxt-proof-of-sql~0.105.0
